# Fake News Detection using Machine Learning
Fake News Detection using Machine Learning Algorithms

This Project is to solve the problem with fake news. 
In this we have used two datasets named "Fake" and "True" from Kaggle.
You can download the file from here https://www.kaggle.com/clmentbisaillon/fake-and-real-news-dataset
I have used five classifiers in this project the are Naive Bayes, Random Forest, Decision Tree,Logistic Regression.
